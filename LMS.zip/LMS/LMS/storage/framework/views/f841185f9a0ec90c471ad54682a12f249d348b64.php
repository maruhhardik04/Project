<section class="hero-home py-5">
    <div class="container pt-5">
      <div class="row">
        <div class="col-lg-8 mx-auto col-sm-3">
          <form class="p-2 rounded shadow-sm bg-white" action="<?php echo e(route('MyBook.index')); ?>" method="GET">
            <div class="input-group">
              <ul class="list-inline mb-0">
                <li class="list-inline-item my-1 my-lg-0">
                  <select class="choices" name="serachBy" data-customclass="btn btn-light bg-white shadow-xs border text-start d-flex align-items-center">
                    <option value="author_name">Author</option>
                    <option value="publisher">Publisher</option>
                    <option value="title_eng"  selected>Title</option>
                    <option value="language">Language</option>
                  </select>
                </li>
                </ul>
              <input class="form-control border-0 me-2 shadow-0" type="search" name="search" placeholder="Search " required>
              <button class="btn btn-primary rounded" type="submit"><i class="fas fa-search"></i></button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section><?php /**PATH E:\LMS\LMS\resources\views/layout/search.blade.php ENDPATH**/ ?>