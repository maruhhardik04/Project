<section class="pb-5">
    <div class="container pb-5">
      <header class="text-center mb-5">
        <h2 class="mb-1">Explore our categories</h2>
      
      </header>
      <div class="row text-center gy-4">
        <div class="col-lg-3 px-lg-2">
          <div class="categories-item card border-0 shadow hover-transition">
            <div class="card-body px-4 py-5">
                  <svg class="svg-icon mb-3">
                    <use xlink:href="#!stack-1"> </use>
                  </svg>
              <h2 class="h5"> <a class="stretched-link reset-anchor-inherit" href="#!">Marketing</a></h2>
              <p class="categories-item-number small mb-0">2 Items</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 px-lg-2">
          <div class="categories-item card border-0 shadow hover-transition">
            <div class="card-body px-4 py-5">
                  <svg class="svg-icon mb-3">
                    <use xlink:href="#!pie-chart-1"> </use>
                  </svg>
              <h2 class="h5"> <a class="stretched-link reset-anchor-inherit" href="#!">Project management</a></h2>
              <p class="categories-item-number small mb-0">2 Items</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 px-lg-2">
          <div class="categories-item card border-0 shadow hover-transition">
            <div class="card-body px-4 py-5">
                  <svg class="svg-icon mb-3">
                    <use xlink:href="#!design-1"> </use>
                  </svg>
              <h2 class="h5"> <a class="stretched-link reset-anchor-inherit" href="#!">Design</a></h2>
              <p class="categories-item-number small mb-0">2 Items</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 px-lg-2">
          <div class="categories-item card border-0 shadow hover-transition">
            <div class="card-body px-4 py-5">
                  <svg class="svg-icon mb-3">
                    <use xlink:href="#!mental-health-1"> </use>
                  </svg>
              <h2 class="h5"> <a class="stretched-link reset-anchor-inherit" href="#!">Idea generation</a></h2>
              <p class="categories-item-number small mb-0">2 Items</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 px-lg-2">
          <div class="categories-item card border-0 shadow hover-transition">
            <div class="card-body px-4 py-5">
                  <svg class="svg-icon mb-3">
                    <use xlink:href="#!bookmark-1"> </use>
                  </svg>
              <h2 class="h5"> <a class="stretched-link reset-anchor-inherit" href="#!">Naming</a></h2>
              <p class="categories-item-number small mb-0">2 Items</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 px-lg-2">
          <div class="categories-item card border-0 shadow hover-transition">
            <div class="card-body px-4 py-5">
                  <svg class="svg-icon mb-3">
                    <use xlink:href="#!checked-window-1"> </use>
                  </svg>
              <h2 class="h5"> <a class="stretched-link reset-anchor-inherit" href="#!">Domain names</a></h2>
              <p class="categories-item-number small mb-0">2 Items</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 px-lg-2">
          <div class="categories-item card border-0 shadow hover-transition">
            <div class="card-body px-4 py-5">
                  <svg class="svg-icon mb-3">
                    <use xlink:href="#!list-details-1"> </use>
                  </svg>
              <h2 class="h5"> <a class="stretched-link reset-anchor-inherit" href="#!">Hosting</a></h2>
              <p class="categories-item-number small mb-0">2 Items</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 px-lg-2">
          <div class="categories-item card border-0 shadow hover-transition">
            <div class="card-body px-4 py-5">
                  <svg class="svg-icon mb-3">
                    <use xlink:href="#!sales-up-1"> </use>
                  </svg>
              <h2 class="h5"> <a class="stretched-link reset-anchor-inherit" href="#!">Market research</a></h2>
              <p class="categories-item-number small mb-0">2 Items</p>
            </div>
          </div>
        </div>
        <div class="col-lg-12 text-center pt-4"><a class="btn btn-primary" href="#!">Show more categories</a></div>
      </div>
    </div>
  </section><?php /**PATH E:\LMS\LMS\resources\views/layout/categories.blade.php ENDPATH**/ ?>