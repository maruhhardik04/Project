<html lang="en">
<head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <style>
        .bcontent {
            margin-top: 10px;
        }
    </style>
</head>
<body>
   
    <div class="container bcontent">
       
        <hr />
      
   
            
            
               
                <div class="row">
                    @foreach ($data as $item)    
                    <div class="col-lg-4 col-md-6 col-sm-12 ">
                        <div class="card" style="width: 18rem;">
                            <img class="card-img-top" src="{{$item->image}}" alt="Card image cap">
                            <div class="card-body">
                              <h5 class="card-title">{{$item->title_eng}}</h5>
                              <h5 class="card-title">{{$item->title_guj}}</h5>
                            </div>
                          </div> 
                    </div>
                    @endforeach 
                  </div>
              
              
          
         
        </div>
        
    </div>
    
</body>
</html>