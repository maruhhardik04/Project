{{-- {{dd($Book)}} --}}
<div class="bardcode">
    <p>{{$b->title_eng}}</p>
 <img src="data:image/png;base64,{{DNS2D::getBarcodePNG($b->id, 'PDF417',3,2)}}" alt="barcode"   />

    <p class="bid">{{$b->id}}</p>

    
</div>