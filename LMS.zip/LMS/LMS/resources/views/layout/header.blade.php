  <!-- navbar-->
  <header class="header">
    <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 py-lg-2">
      <div class="container"><a class="navbar-brand py-3 d-flex align-items-center" href="index.html"><img src="img/logo.png" alt="" width="250" height="50"><span class="text-uppercase text-small fw-bold text-dark ms-2 mb-0"></span></a>
        <button class="navbar-toggler navbar-toggler-end" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ms-auto">
            


            <li class="nav-item">
                  <!-- Navbar link--><a class="nav-link  active" href="/home">Home</a>
            </li>
            <li class="nav-item">
                  <!-- Navbar link--><a class="nav-link " href="{{ route('MyBook.index') }}">Books</a>
            </li>
            <li class="nav-item">
                  <!-- Navbar link--><a class="nav-link" href="{{route('profile')}}">Profile</a>
            </li>
              <div class="dropdown-menu mt-lg-3 shadow-sm"><a class="dropdown-item" href="index.html">Home</a><a class="dropdown-item" href="category.html">Category</a><a class="dropdown-item" href="detail.html">Detail</a></div>
            </li>
            <li class="nav-item ms-lg-2 py-2 py-lg-0"><a class="btn btn-primary" href="#listingModal" data-bs-toggle="modal">Add listing</a></li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
  <!--  Modal -->
  <div class="modal fade" id="listingModal" tabindex="-1" role="dialog" aria-labelledby="listingModal" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header px-lg-5">
          <h5 class="modal-title" id="listingModalLabel">Add Listing</h5>
          <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body px-lg-5">
          <form action="#!">
            <div class="row gy-3">
              <div class="col-lg-6">
                <label class="form-label" for="fullName">Full name</label>
                <input class="form-control" id="fullName" type="text" name="fullname" placeholder="Your full name">
              </div>
              <div class="col-lg-6">
                <label class="form-label" for="email">Email Address</label>
                <input class="form-control" id="email" type="email" name="email" placeholder="Your email address">
              </div>
              <div class="col-lg-6">
                <label class="form-label" for="fullName">Listing Type</label>
                <select class="choices" data-customclass="form-control">
                  <option value>Choose listing type</option>
                  <option value="tool">Tool</option>
                  <option value="resource">Resource</option>
                </select>
              </div>
              <div class="col-lg-6">
                <label class="form-label" for="istingTitle">Listing title</label>
                <input class="form-control" id="istingTitle" type="text" name="listing-title" placeholder="Title of your title">
              </div>
              <div class="col-lg-6">
                <label class="form-label" for="listingUrl">Listing URL</label>
                <input class="form-control" id="listingUrl" type="text" name="listing-url" placeholder="Listing website url">
              </div>
              <div class="col-lg-6">
                <label class="form-label" for="listingCategory">Listing category</label>
                <select class="choices" data-customclass="form-control">
                  <option value>Choose category</option>
                  <option value="marketing">Marketing </option>
                  <option value="idea generation">Idea generation </option>
                  <option value="design">Design </option>
                  <option value="naming">Naming </option>
                  <option value="domain names">Domain names </option>
                  <option value="sales">Sales </option>
                  <option value="finance">Finance </option>
                  <option value="project management">Project management </option>
                  <option value="hosting">Hosting </option>
                  <option value="social tools">Social tools </option>
                </select>
              </div>
              <div class="col-lg-12">
                <label class="form-label" for="listingDescription">Listing description</label>
                <textarea class="form-control" id="listingDescription" name="listing-description" rows="5" placeholder="Add a small brief about your listing."></textarea>
              </div>
              <div class="col-lg-6 mb-lg-0">
                <label class="form-label" for="listingThumb">Listing thumbnail</label>
                <input class="form-control" id="listingThumb" type="file" name="listing-thumb">
              </div>
              <div class="col-lg-6 mb-lg-0">
                <label class="form-label" for="listingCover">Listing cover</label>
                <input class="form-control" id="listingCover" type="file" name="listing-cover">
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer justify-content-start px-lg-5">
          <button class="btn btn-primary" type="submit">Submit listing</button>
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>