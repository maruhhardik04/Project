 
<?php $__env->startSection('main'); ?>
    

    
<?php echo $__env->make('layout.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="py-5">
 <div class="container py-5">
<div class="row gy-5">
 <div class="col-lg-3 order-2 order-lg-1">
      <div class="card border-0 shadow-sm mb-4 p-2">
        <div class="card-body">
          <h2 class="h5 mb-4">Choose category</h2>
           <?php $__currentLoopData = $data['cat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="mb-2">
              <a class="page-link rounded shadow-sm px-3" href="<?php echo e(route('MyBook.index',['id'=>$cat->id])); ?>"><?php echo e($cat->cat_name); ?>

              </a>
          
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
   
  </div>
  <!-- Listing-->

  <div class="col-lg-9 order-1 order-lg-2">
    <!-- Listing sorting-->

    <div class="row mb-4 align-items-end"> 
      <div class="col-md-5">
        <p class="h6 mb-0 p-3 p-md-0">Show <?php echo e($data['books']->count()); ?> results</p>
      </div>
    </div>
    <!-- Listing items-->
    <div class="row mb-4 gy-4">
      <?php $__currentLoopData = $data['books']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-lg-4 col-md-6">
        <div class="card border-0 shadow hover-transition">
          <img class="card-img-top img-fluid" src="<?php echo e($item->image); ?>" alt="...">
            <div class="card-body p-5">
              
              
                <a class="stretched-link reset-anchor">
                    <h3 class="h5">
                    <?php echo e($item->title_guj); ?>

                     </h3>
                     
                     <h3 class="h5">
                        <?php echo e($item->title_eng); ?>

                         </h3>
                   </a>
          
            <p class="text-md text-muted">Language: <?php echo e($item->language); ?></p>     
              <p class="text-sm text-muted">Available Copies:<?php echo e(8); ?></p>

              <div class="d-flex ms-2 align-items-center"><span class="small text-muted me-1">By</span>
                <h6 class="mb-0"><?php echo e($item->author_name); ?></h6>
              </div>
            </div>
          </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 

    <?php echo e($data['books']->links('layout.pagination')); ?>


    
  </div>
</section>
    <?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LMS\LMS\resources\views/Book.blade.php ENDPATH**/ ?>