<section class="pb-5">
    <div class="container pb-5">
      <header class="text-center mb-5">
        <h2 class="mb-1">Explore our categories</h2>
        <p class="text-muted text-sm">Lorem ipsum dolor sit amet, consetetur sadipscing elitr.</p>
      </header>
      <div class="row">
        <div class="col-lg-4 mb-4 mb-lg-0">
              <div class="card border-0 shadow hover-transition"><a href="#!"><img class="card-img-top img-fluid" src="img/blog-1.jpg" alt="..."></a>
                <div class="card-body p-5">
                  <p class="text-sm text-muted mb-2">11 February, 2020</p>
                  <h3 class="h5"><a class="stretched-link reset-anchor" href="#!">How To Get More Reviews For Your Startup Product</a></h3>
                  <p class="text-sm text-muted">The quality of customer service can make or break a buyer’s relationship with the seller. According to the 2017 Customer Service Barometer...</p>
                  <div class="d-flex ms-2 align-items-center"><span class="small text-muted me-1">By</span>
                    <h6 class="mb-0">Ali Mesee</h6>
                  </div>
                </div>
              </div>
        </div>
        <div class="col-lg-4 mb-4 mb-lg-0">
              <div class="card border-0 shadow hover-transition"><a href="#!"><img class="card-img-top img-fluid" src="img/blog-2.jpg" alt="..."></a>
                <div class="card-body p-5">
                  <p class="text-sm text-muted mb-2">11 February, 2020</p>
                  <h3 class="h5"><a class="stretched-link reset-anchor" href="#!">Increasing Engagement Among Email Subscribers</a></h3>
                  <p class="text-sm text-muted">The quality of customer service can make or break a buyer’s relationship with the seller. According to the 2017 Customer Service Barometer study published by...</p><span class="text-primary">Read more</span>
                </div>
              </div>
        </div>
        <div class="col-lg-4">
              <div class="card border-0 shadow hover-transition"><a href="#!"><img class="card-img-top img-fluid" src="img/blog-3.jpg" alt="..."></a>
                <div class="card-body p-5">
                  <p class="text-sm text-muted mb-2">11 February, 2020</p>
                  <h3 class="h5"><a class="stretched-link reset-anchor" href="#!">Lessons in Leadership: Q&amp;A with William Erbey</a></h3>
                  <p class="text-sm text-muted">The quality of customer service can make or break a buyer’s relationship with the seller. According to the 2017 Customer Service Barometer study published by...</p><span class="text-primary">Read more</span>
                </div>
              </div>
        </div>
      </div>
    </div>
  </section><?php /**PATH E:\LMS\LMS\resources\views/layout/item.blade.php ENDPATH**/ ?>