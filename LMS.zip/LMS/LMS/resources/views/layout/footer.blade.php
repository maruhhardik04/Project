<footer style="background: #111;">
    <div class="container py-4">
      <div class="row py-5 gy-3">
        <div class="col-md-4 col-sm-12">
          <div class="d-flex align-items-center mb-3"><img src="img/logo-footer.svg" alt="" width="30"><span class="text-uppercase text-sm fw-bold text-white ms-2">Listings</span></div>
          <p class="text-muted text-sm fw-light mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>
          <ul class="list-inline mb-0 text-white">
            <li class="list-inline-item"><a class="reset-anchor text-sm" href="#!"><i class="fab fa-facebook-f"></i></a></li>
            <li class="list-inline-item"><a class="reset-anchor text-sm" href="#!"><i class="fab fa-twitter"></i></a></li>
            <li class="list-inline-item"><a class="reset-anchor text-sm" href="#!"><i class="fab fa-pinterest"></i></a></li>
            <li class="list-inline-item"><a class="reset-anchor text-sm" href="#!"><i class="fab fa-linkedin-in"></i></a></li>
          </ul>
        </div>
        <div class="col-md-4 col-sm-6">
          <h6 class="pt-2 text-white">Useful links</h6>
          <div class="d-flex flex-wrap">
            <ul class="list-unstyled text-muted mb-0 mb-3 me-4">
              <li><a class="reset-anchor text-sm" href="#!">Tools</a></li>
              <li><a class="reset-anchor text-sm" href="#!">Resources</a></li>
              <li><a class="reset-anchor text-sm" href="#!">About us</a></li>
              <li><a class="reset-anchor text-sm" href="#!">Write to us</a></li>
            </ul>
            <ul class="list-unstyled text-muted mb-0">
              <li><a class="reset-anchor text-sm" href="#!">Privacy Policy </a></li>
              <li><a class="reset-anchor text-sm" href="#!">Cookie Policy</a></li>
              <li><a class="reset-anchor text-sm" href="#!">Terms &amp; Conditions</a></li>
            </ul>
          </div>
        </div>
        <div class="col-md-4 col-sm-6">
          <h6 class="pt-2 text-white">Newsletter</h6>
          <p class="text-muted text-sm">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>
          <form action="">
            <div class="input-group">
              <input class="form-control bg-none border-dark text-white" type="email" placeholder="Type your email address" aria-describedby="button-addon2">
              <button class="btn btn-light" id="button-addon2" type="submit"><i class="fas fa-paper-plane"></i></button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div class="copyrights py-4" style="background: #0e0e0e">
      <div class="container">
        <div class="row text-center gy-2">
          <div class="col-sm-6 text-lg-start">
            <p class="mb-0 text-muted mb-0 text-sm">&copy; 2022 All rights reserved.</p>
          </div>
          <div class="col-sm-6 text-md-end">
            <p class="mb-0 text-muted mb-0 text-sm">Develop by <a class="reset-anchor text-primary">shadow</a>.</p>
            <!-- If you want to remove the backlink, please purchase the Attribution-Free License.-->
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!-- JavaScript files-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/glightbox/js/glightbox.min.js"></script>
  <script src="vendor/swiper/swiper-bundle.min.js"></script>
  <script src="vendor/choices.js/public/assets/scripts/choices.min.js"></script>
  <script src="js/front.js"></script>
 
  <!-- FontAwesome CSS - loading as last, so it doesn't block rendering-->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
