 @extends('layout.default')
@section('main')
    

    
@include('layout.search')
<section class="py-5">
 <div class="container py-5">
<div class="row gy-5">
 <div class="col-lg-3 order-2 order-lg-1">
      <div class="card border-0 shadow-sm mb-4 p-2">
        <div class="card-body">
          <h2 class="h5 mb-4">Choose category</h2>
           @foreach($data['cat'] as $cat) 
          <div class="mb-2">
              <a class="page-link rounded shadow-sm px-3" href="{{route('MyBook.index',['id'=>$cat->id])}}">{{ $cat->cat_name }}
              </a>
          
          </div>
          @endforeach
        </div>
      </div>
   
  </div>
  <!-- Listing-->

  <div class="col-lg-9 order-1 order-lg-2">
    <!-- Listing sorting-->

    <div class="row mb-4 align-items-end"> 
      <div class="col-md-5">
        <p class="h6 mb-0 p-3 p-md-0">Show {{ $data['books']->count() }} results</p>
      </div>
    </div>
    <!-- Listing items-->
    <div class="row mb-4 gy-4">
      @foreach ($data['books'] as $item)
      <div class="col-lg-4 col-md-6">
        <div class="card border-0 shadow hover-transition">
          <img class="card-img-top img-fluid" src="{{$item->image}}" alt="...">
            <div class="card-body p-5">
              {{-- <p class="text-sm text-muted mb-2">11 February, 2020</p> --}}
              
                <a class="stretched-link reset-anchor">
                    <h3 class="h5">
                    {{$item->title_guj}}
                     </h3>
                     
                     <h3 class="h5">
                        {{$item->title_eng}}
                         </h3>
                   </a>
          
            <p class="text-md text-muted">Language: {{$item->language}}</p>     
              <p class="text-sm text-muted">Available Copies:{{8}}</p>

              <div class="d-flex ms-2 align-items-center"><span class="small text-muted me-1">By</span>
                <h6 class="mb-0">{{$item->author_name}}</h6>
              </div>
            </div>
          </div>
      </div>
      @endforeach
    </div>
 

    {{$data['books']->links('layout.pagination')}}

    
  </div>
</section>
    @endsection
 