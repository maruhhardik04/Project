
<div class="bardcode">
    <p><?php echo e($b->title_eng); ?></p>
 <img src="data:image/png;base64,<?php echo e(DNS2D::getBarcodePNG($b->id, 'PDF417',3,2)); ?>" alt="barcode"   />

    <p class="bid"><?php echo e($b->id); ?></p>

    
</div><?php /**PATH E:\LMS\LMS\resources\views/welcome.blade.php ENDPATH**/ ?>