<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Books extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('books', function (Blueprint $table) {
            $table->id();
            $table->string('acc_no')->unique(); 	
            $table->string('class_no')->unique();	
            $table->string('title_eng');
            $table->string('title_guj');	
            $table->string('author_name'); 	
            $table->string('publisher'); 	
            $table->string('place'); 
            $table->string('year');
            $table->unsignedInteger('price');		
            $table->unsignedInteger('pages');	
            $table->string('language');	
            $table->string('edition');
            $table->string('isbn');
            $table->string('image');		
            $table->unsignedBigInteger('category');
            $table->string('aqcuisition_type');	
            $table->date('aqcuisition_date');
            $table->timestamps();	
            $table->foreign('category')
                    ->references('id')
                    ->on('categories')
                    ->onDelete('cascade');	
           
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
