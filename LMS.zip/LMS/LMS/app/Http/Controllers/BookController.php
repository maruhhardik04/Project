<?php

namespace App\Http\Controllers;

use App\Models\book;
use App\Models\category;
use Books;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Date;

class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $req,$id=0)
    {

       $id=$req->id; 
       
       
     
        $cat=category::all();

        if($req->id != NULL)
        {
            $books=Book::where('category',$id)->paginate(6);
        }
        else{
            if($req->search)
            {
               $books=Book::where($req->serachBy,$req->search)->paginate(6);     
            }
            else
            {
                $books=Book::paginate(6);       
            }
        }
       

        
      

        $data=["books"=>$books,"cat"=>$cat];
        return view('Book',compact('data'));     

        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $b=new book();

        $b->acc_no="7";
        $b->class_no="7";
        $b->title_eng="Book1";
        $b->title_guj="પુસ્તક1";
        $b->author_name="cdf";
        $b->publisher="cde";
        $b->place="sdg";
        $b->year="2000";
        $b->price=150;
        $b->pages=200;
        $b->language="English";
        $b->edition="1st";
        $b->isbn="186543";
        $b->image="https://pngimg.com/uploads/book/book_PNG2111.png";
        $b->category=1;
        $b->aqcuisition_type="sfgvd";
        $b->aqcuisition_date=Carbon::now()->toDateTimeString();
        $b->save();
         
        echo Book::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\book  $book
     * @return \Illuminate\Http\Response
     */
    public function show(book $book)
    {
           $b=Book::first();
           return view('welcome')->with('b',$b);
           
    }


    public function search(Request $request)
    {
        
    } 

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\book  $book
     * @return \Illuminate\Http\Response
     */
    public function edit(book $book)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\book  $book
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, book $book)
    {
        //
    }




    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\book  $book
     * @return \Illuminate\Http\Response
     */
    public function destroy(book $book)
    {
        //
    }
}
